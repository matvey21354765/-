from __future__ import annotations
import logging
from datetime import datetime, timezone
from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest
from app.models.database import Signal
from app.services.user_service import get_all_active_users

logger = logging.getLogger(__name__)

_DIR = {"LONG": "🟢 LONG", "SHORT": "🔴 SHORT", "NO TRADE": "🟡 NO TRADE"}
_STARS = {10: "★★★★★", 9: "★★★★★", 8: "★★★★☆", 7: "★★★★☆",
          6: "★★★☆☆", 5: "★★★☆☆", 4: "★★☆☆☆", 3: "★★☆☆☆", 2: "★☆☆☆☆", 1: "★☆☆☆☆"}


def _p(v: float) -> str:
    if v >= 1000:
        return f"${v:,.2f}"
    if v >= 1:
        return f"${v:.4f}"
    return f"${v:.6f}"


def format_signal(sig: Signal) -> str:
    stars = _STARS.get(sig.signal_rating, "★★★☆☆")
    reasons = [r for r in (sig.reasons or "").split("\n") if r.strip()]
    reasons_text = "\n".join(f"  • {r}" for r in reasons)
    sl_pct = abs(sig.entry_price - sig.stop_loss) / sig.entry_price * 100
    tp1_pct = abs(sig.take_profit_1 - sig.entry_price) / sig.entry_price * 100
    tp2_pct = abs(sig.take_profit_2 - sig.entry_price) / sig.entry_price * 100
    tp3_pct = abs(sig.take_profit_3 - sig.entry_price) / sig.entry_price * 100
    prob_line = f"  Вероятность:  🟢 {sig.prob_up:.0f}%↑  🔴 {sig.prob_down:.0f}%↓\n" if sig.prob_up else ""
    trend_line = f"  Тренд:        <b>{sig.trend_strength}</b>\n" if sig.trend_strength else ""
    tf_line = f"  Горизонт:     <b>{sig.timeframe}</b>\n" if sig.timeframe else ""
    analysis = (sig.full_analysis or "")[:600].replace("\n", "\n  ")

    return (
        f"╔══════════════════════════════\n"
        f"║  {_DIR.get(sig.direction, sig.direction)}  ·  <b>{sig.coin}/USDT</b>\n"
        f"║  {stars}  Рейтинг <b>{sig.signal_rating}/10</b>\n"
        f"╠══════════════════════════════\n"
        f"  Уверенность:  <b>{sig.confidence:.0f}%</b>\n"
        f"{trend_line}"
        f"{prob_line}"
        f"{tf_line}"
        f"╠══════════════════════════════\n"
        f"  Вход:          <b>{_p(sig.entry_price)}</b>  [{sig.entry_type}]\n"
        f"  Stop Loss:     <b>{_p(sig.stop_loss)}</b>  (-{sl_pct:.1f}%)\n"
        f"  Take Profit 1: <b>{_p(sig.take_profit_1)}</b>  (+{tp1_pct:.1f}%)\n"
        f"  Take Profit 2: <b>{_p(sig.take_profit_2)}</b>  (+{tp2_pct:.1f}%)\n"
        f"  Take Profit 3: <b>{_p(sig.take_profit_3)}</b>  (+{tp3_pct:.1f}%)\n"
        f"  R/R:           <b>1:{sig.risk_reward:.1f}</b>\n"
        f"╠══════════════════════════════\n"
        f"  <b>📊 Причины входа:</b>\n"
        f"{reasons_text}\n"
        f"╠══════════════════════════════\n"
        f"  <b>📝 Анализ:</b>\n"
        f"  {analysis}\n"
        f"╚══════════════════════════════\n"
        f"<i>🕐 {datetime.now(timezone.utc).strftime('%d.%m.%Y %H:%M')} UTC  ·  DAO Signals #{sig.id}</i>"
    )


async def broadcast_signal(bot: Bot, sig: Signal) -> tuple[int, int]:
    users = await get_all_active_users()
    text = format_signal(sig)
    sent = blocked = 0
    for user in users:
        if not user.has_access():
            continue
        try:
            await bot.send_message(user.telegram_id, text, parse_mode="HTML")
            sent += 1
        except TelegramForbiddenError:
            blocked += 1
        except TelegramBadRequest as e:
            logger.warning(f"Bad request {user.telegram_id}: {e}")
        except Exception as e:
            logger.error(f"Send error {user.telegram_id}: {e}")
    logger.info(f"Broadcast #{sig.id}: sent={sent} blocked={blocked}")
    return sent, blocked
